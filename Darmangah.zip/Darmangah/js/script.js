
  function initCategoryBar() {
    var $overlay = $(".js-menu-overlay"),
      $naviOverlay = $(".js-navi-overlay"),
      $megaMenuMain = $('.js-mega-menu-main-item'),
      $megaMenuOptionsContainer = $(".js-mega-menu-categories-options"),
      $hoverEffect = $(".js-navi-new-list-category-hover"),
      $headerLinks = $('.js-categories-bar-item'),
      $megaMenuCategory = $('.js-mega-menu-category'),
      $searchBar = $('.js-search'),
      $searchResults = $('.js-search-results');

    var moveHover = function (self) {
      var parent = self
        .parent()
        .parent()
        .parent();

      $hoverEffect
        .css("width", self.width())
        .css(
          "right",
          parent.width()
          - (self.offset().left + self.width())
          + parent.offset().left
        );
      $hoverEffect.css("transform", "scaleX(1)");
    };

    var removeHover = function () {
      $hoverEffect.css("transform", "scaleX(0)");
    };

    $headerLinks.hover(function () {
        moveHover.call(this, $(this));
      },
      function () {
        removeHover.call(this, $(this));
      });

    $megaMenuMain.on('click', function (e) {
      e.stopPropagation();
    });

    var hoverAction;
    $megaMenuMain.hover(
      function () {
        var $this = $(this);
        hoverAction = setTimeout(function () {
          $this.children(".js-mega-menu-categories-options").css('display', 'flex');
          $naviOverlay.addClass("is-active");
          $searchResults.removeClass("is-active");
          $searchBar.removeClass("is-active");
        }, 200);
      },
      function () {
        hoverAction && clearTimeout(hoverAction);
        $naviOverlay.removeClass("is-active");
        $megaMenuOptionsContainer.hide()
      });

    $megaMenuCategory.hover(
      function () {


        $megaMenuOptionsContainer.find('.js-categories-ad').removeClass('ad-is-active');
        $megaMenuOptionsContainer.find('#categories-ad-' + $(this).data('index')).addClass('ad-is-active');


        $megaMenuOptionsContainer.find('.js-mega-menu-category-options').removeClass('is-active');
        $megaMenuCategory.removeClass('c-navi-new-list__inner-category--hovered');
        $(this).addClass('c-navi-new-list__inner-category--hovered');
        $megaMenuOptionsContainer.find('#categories-' + $(this).data('index')).addClass('is-active');
      },

      function () {}
    );

    $overlay.hover(function () {
      if (!$(this).is(".is-active")) return true;
    });

    $megaMenuCategory.hover(
      function () {


        $megaMenuOptionsContainer.find('.js-categories-ad').removeClass('ad-is-active');
        $megaMenuOptionsContainer.find('#categories-ad-' + $(this).data('index')).addClass('ad-is-active');


        $megaMenuOptionsContainer.find('.js-mega-menu-category-options').removeClass('is-active');
        $megaMenuCategory.removeClass('c-navi-new-list__inner-category--hovered');
        $(this).addClass('c-navi-new-list__inner-category--hovered');
        $megaMenuOptionsContainer.find('#categories-' + $(this).data('index')).addClass('is-active');
      },

      function () {}
    );

  };

  function initStatic() {
    var $overlay = $(".js-menu-overlay"),
      $naviOverlay = $(".js-navi-overlay"),
      $newCategories = $(".js-navi-new-list-categories"),
      $newCategoryItem = $(".js-navi-new-list-category"),
      $hoverEffect = $(".js-navi-new-list-category-hover"),
      allCategoriesButton = $(".js-navi-new-list__all-links"),
      sentBanners = [];

    this.openCategories = false;
    var mainJs = this;

    $(".js-navi").hover(function () {
      $(this)
        .find("img[data-src]")
        .each(function () {
          $(this)
            .attr("src", $(this).attr("data-src"))
            .removeAttr("data-src");
        });
    });

    var moveHover = function (self) {
      var parent = self
        .parent()
        .parent()
        .parent();

      $hoverEffect
        .css("width", self.width())
        .css(
          "right",
          parent.width()
          - (self.offset().left + self.width())
          + parent.offset().left
        );
      if ($(this).hasClass("is-fmcg")) {
        $hoverEffect.addClass("is-fmcg");
      } else {
        $hoverEffect.removeClass("is-fmcg");
      }
      $hoverEffect.css("transform", "scaleX(1)");
    };

    var removeHover = function () {
      $hoverEffect.css("transform", "scaleX(0)");
    };

    var handlerHover = function () {
      clearTimeout(this.closeTimer);
      var self = $(this);

      this.timer = setTimeout(function () {
        $("body").click();
        $naviOverlay.addClass("is-active");
        self.addClass("can-show-menu");
        self.siblings(".js-navi-new-list-category").addClass("can-show-menu");
        self.find(".js-navi-new-list-category").addClass("can-show-menu");
        mainJs.openCategories = true;
        var id = self.find(".c-adplacement__item").data("id");

        if (id && sentBanners.indexOf(id) < 0) {
          snt("dkBannerViewed", {
            bannerId: id,
            created_at: Date.now()
          });
          sentBanners.push(id);
        }
        $(".js-search-results").removeClass("is-active");
      }, 200);
      if (self.hasClass("js-navi-new-list-category")) {
        moveHover.call(this, self);
      }
    };
    var handlerOut = function () {
      clearTimeout(this.timer);
      var self = this;

      this.closeTimer = setTimeout(function () {
        if ($(".js-search-results").hasClass("is-active")) return;
        $(self).hasClass("js-navi-new-list-categories")
          ? $naviOverlay.removeClass("is-active")
          : "";
        $(self)
          .find(".js-navi-new-list-category")
          .removeClass("can-show-menu");
        $(self).hasClass("can-show-menu")
          ? $(self).removeClass("can-show-menu")
          : "";
        mainJs.openCategories = false;
      }, 200);
      removeHover();
    };

    // $('.js-navi-list-promotion-item').hover(function () {
    //     moveHover.call(this, $(this));
    // }, removeHover);

    var $w = $(window),
      lastY = $w.scrollTop();

    $(window).scroll(function () {
      var currentPosition = $w.scrollTop();

      if (!mainJs.openCategories) {
        return (lastY = currentPosition);
      }
      if (currentPosition - lastY < -5) {
        var e = jQuery.Event("mouseout");

        $newCategories.trigger(e);

        $newCategoryItem.trigger(e);
      }
      lastY = currentPosition;
    });

    $newCategories.hover(handlerHover, handlerOut);
    $newCategoryItem.hover(handlerHover, handlerOut);
    allCategoriesButton.hover(function (e) {
      e.stopPropagation();
      e.preventDefault();
      $naviOverlay.removeClass("is-active");
    });
    $overlay.hover(function () {
      if (!$(this).is(".is-active")) return true;
    });

    $(".js-expert-article-button").on("click", function (e) {
      var $this = $(this),
        $article = $this.closest(".js-expert-article");

      if ($article.hasClass("is-active")) {
        $article.removeClass("is-active");
      } else {
        $article.addClass("is-active");
      }

      e.preventDefault();

      window.dispatchEvent(new Event("scroll"));
    });

    var $deliveryLabels = $(".js-delivery-label");

    $deliveryLabels.click(function () {
      var $this = $(this);

      if ($this.hasClass("is-read-only")) {
        return;
      }

      $deliveryLabels.removeClass("is-selected");
      $this.addClass("is-selected");
    });

    $deliveryLabels.each(function () {
      var $this = $(this);
      var $radio = $this.find('input[type="radio"]');

      if ($radio.is(":checked")) {
        $this.addClass("is-selected");
      }
    });
  };
  $(document).ready(function () {
    initCategoryBar();
    initStatic();

  });

if ($('.owl-slider').length) {
  $(document).ready(function () {
    var owl = $('.owl-slider');
    $('.owl-slider').owlCarousel({
      loop: true,
      margin: 0,
 smartSpeed:1000,
     autoplay: true,
      navSpeed: 500,
      items: 1,
      rtl: true,
      dots: true,
      autoplay: true,
      onInitialized: startProgressBar,
      onTranslate: resetProgressBar,
      onTranslated: startProgressBar,
         responsive: {
      0: {
         nav: false
      },
      768: {
         nav: true
      }


    }
    });

    function startProgressBar() {
      // apply keyframe animation
      $(".slide-progress").css({
        width: "100%",
        transition: "width 5000ms"
      });
    }

    function resetProgressBar() {
      $(".slide-progress").css({
        width: 0,
        transition: "width 0s"
      });
    }
    owl.on('changed.owl.carousel', function (event) {
      var item = event.item.index - 2; // Position of the current item
      $('.main-text-slider').removeClass('animated slideInUp');
      $('.owl-item').not('.cloned').eq(item).find('.main-text-slider').addClass('animated slideInUp');

      $('.lnk-slide2').removeClass('animated zoomIn');
      $('.owl-item').not('.cloned').eq(item).find('.lnk-slide2').addClass('animated zoomIn');

      $('.lnk-slide1').removeClass('animated slideInUp');
      $('.owl-item').not('.cloned').eq(item).find('.lnk-slide1').addClass('animated slideInUp');

    });
  });
}




      $('.scrollup').click(function () {
        $("html,body").animate({
          scrollTop: 0
        }, 1000);
        return false;
      });

  
    if ($('.menu').length) {
      $(document).ready(function () {
        $(window).scroll(function () {
          if ($(window).scrollTop() > 100) {
            $(".menu").addClass("sticky-menu");
          } else {
            $(".menu").removeClass("sticky-menu");
          }
        });
      });
    }
     


  
     $('.search').click(function () {
      $('.box-search').toggleClass('SearchOpen ');
    });
    $('.btSearchInnerClose').click(function () {
      $('.box-search').removeClass('SearchOpen ');
    });
  
new WOW().init();
if (matchMedia('only screen and (max-width: 767.99px)').matches) {
  $(".set > span").on("click", function () {
    if ($(this).hasClass('active')) {
      $(this).removeClass("active");
      $(this).siblings('.content').slideUp(200);
      $(".set > span i").removeClass("fas fa-chevron-up").addClass("fas fa-chevron-up");
    } else {
      $(".set > span i").removeClass("fas fa-chevron-up").addClass("fas fa-chevron-up");
      $(this).find("i").removeClass("fas fa-chevron-down").addClass("fas fa-chevron-up");
      $(".set > span").removeClass("active");
      $(this).addClass("active");
      $('.content').slideUp(200);
      $(this).siblings('.content').slideDown(200);
    }

  });
}
if ($('.owl-new2').length) {
  $(document).ready(function () {
    var owl = $('.owl-new2');
    $('.owl-new2').owlCarousel({
      loop: true,
      margin: 0,
     animateIn: 'fadeIn',
    animateOut: 'fadeOut',	
    autoplay: true,
      navSpeed: 500,
      items: 1,
      rtl: true,
      nav:false,
      dots: true,
      autoplay: true,

    });

  });
}



 $('.menuTrigger').click(function () {
  $('.panel-menu').toggleClass('isOpen');

});

$('.openSubPanel').click(function () {
  $(this).next('.subPanel').addClass('isOpen');
});

$('.closeSubPanel').click(function () {
  $(this).closest(".subPanel").removeClass("isOpen");
});

$("#panel-menu").on("click", function (e) {
  var target = $(e.target);
  if (target.attr('id') == 'menu-toggle' || target.parents('#panel-menu').length > 0 || target.parents('.panel-menu').length > 0) {
    console.log('id: ' + target.attr('id') + 'contains: ' + $.contains(target, $('.panel-menu')));
  } else {
    if ($(".panel-menu").hasClass('isOpen'))
      $(".panel-menu").removeClass("isOpen");
    $('.subPanel').removeClass('isOpen');
  }

});

$('.closePanel').click(function () {
  $('.panel-menu').removeClass('isOpen');
  $('.subPanel').removeClass('isOpen');

});
if ($('.owl-blog').length) {
var heroSlider = $('.owl-blog');
		  var owlCarouselTimeout = 3500;	
		$('.owl-blog').owlCarousel({
		  autoplay: true,
      nav:true,
      dots:true,
		  loop: true,
		  smartSpeed:1000,
		  rtl:true,
      margin:20,

		  lazyLoad: true,
		  responsive:{
				0:{
          dots:true,
          nav:false,
          stagePadding: 20,
					items:1
				},
				500:{
          dots:true,
          nav:false,
					items:2
				},
				768:{
          dots:true,
          nav:false,
					items:3
				
				},
				1200:{
          dots:true,
          nav:true,
					items:5

				}
				
			}
		});
  }
  if ($('.owl-spetial-news').length) {
    var heroSlider = $('.owl-spetial-news');
		  var owlCarouselTimeout = 3500;	
		$('.owl-spetial-news').owlCarousel({
		  autoplay: true,
		  loop: true,
		  smartSpeed:1000,
		  rtl:true,
		  lazyLoad: true,
      responsive:{
				0:{
          stagePadding: 20,
					items:1
				},
				500:{
          stagePadding: 20,
					items:1
				},
				768:{

					items:1
				
				}
				
			}

		});
  }
  $('.customers-carousel').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
    navText : ["<i class='fa fa-arrow-left'></i>","<i class='fa fa-arrow-right'></i>"],
    responsive:{
        320:{
            items:1
        },
        767:{
            items:4
        },
        1050:{
            items:8
        }
    }
})
